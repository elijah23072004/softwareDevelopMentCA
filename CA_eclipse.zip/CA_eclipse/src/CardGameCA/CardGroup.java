package CardGameCA;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.ArrayList;

public class CardGroup {
    private List<Card> cards;
    private ReadWriteLock lock = new ReentrantReadWriteLock();

    /**
     * Constructor for objects of class CardGroup
     * @param cards the cards to be added to the group
     */
    public CardGroup(List<Card> cards)
    {
        this.cards = cards;
    }
    /** 
     * Constructor for objects of class CardGroup where no cards are added 
     */
    public CardGroup(){
        cards = new ArrayList<Card>();
    }

    /**
     * Returns a list of cards in the group where the list is copied to avoid concurrency issues (cards do not need to be copied since they are readonly objects)
     * @return List of cards 
     */
    public List<Card> getCards()
    {
        lock.readLock().lock();

        List<Card> out = new ArrayList<Card>();
        for(int i=0; i<cards.size(); i++)
        {
            out.add(cards.get(i));
        }
        lock.readLock().unlock();
        return out;
    }

    /**
     * Adds a card to the group
     * @param card card to be added
     */
    public void addCard(Card card)
    {
        lock.writeLock().lock();
        cards.add(card);
        lock.writeLock().unlock();
    }
    /**
     * Removes a card from the group
     * @param index index of card to be removed
     */
    public void removeCard(int index)
    {
        lock.writeLock().lock();
        cards.remove(index);
        lock.writeLock().unlock();
    }

    /**
     * Removes and returns first card from the group
     * @return card to be removed
     */
    public Card popCard()
    {
        lock.writeLock().lock();
        Card temp = cards.get(0);
        cards.remove(0);
        lock.writeLock().unlock();
        return temp;        
    }

    /**
     * Returns the card at the given index
     * @param index 
     * @return card at given index 
     */
    public Card getCard(int index)
    {
        lock.readLock().lock();
        Card card = cards.get(index);
        lock.readLock().unlock();
        return card;
    }

    /**
     * Returns the number of cards in the group
     * @return number of cards in the group
     */
    public int size()
    {
        lock.readLock().lock();
        int size = cards.size();
        lock.readLock().unlock();
        return size;
    }

    /**
     * Returns whether the group is empty
     * @return true if no cards in group false if there are cards in group
     */
    public boolean isEmpty()
    {
        return size() == 0;
    }

    /**
     * Adds a list of cards to the group
     * @param cards cards to be added
     */
    public void addCards(List<Card> cards)
    {
        lock.writeLock().lock();
        this.cards.addAll(cards);
        lock.writeLock().unlock();
    }
    
    /**
     * Returns a string representation of the group where the cards are represented by their rank
     * @return string representation of the group
     */
    public String toString()
    {
        lock.readLock().lock();
        String temp = "";
        for(int i=0; i<cards.size(); i++)
        {
            temp += cards.get(i).rank + " ";
        }
        lock.readLock().unlock();
        return temp.strip();
    }
}
