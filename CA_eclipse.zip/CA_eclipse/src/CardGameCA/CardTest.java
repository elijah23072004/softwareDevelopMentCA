package CardGameCA;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CardTest {

	@Test
	void Ranktest() {
		Card card = new Card(3);
		assertEquals(card.rank, 1);
	}

}
