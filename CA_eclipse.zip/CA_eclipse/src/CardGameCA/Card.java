package CardGameCA;
public class Card {
    public final int rank;
    /**
     * Constructor for objects of class Card
     * @param rank the rank of the card
     */
    public Card(int rank) {
        this.rank = rank;
    }

}
