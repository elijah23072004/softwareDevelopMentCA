package CardGameCA;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;


public class Player {
    
    private CardGroup deck;
    private CardGroup hand;
    public int ownnumber;
    private Player nextplayer;
    private Boolean gameStillInPlay;
    private String logText;
    private int winner;
    private FileOutputStream writer;



    /**
     * Constructor for Player with 2 arguments
     * 
     * @param ownnumber player number so they can know what cards to discard
     * @param nextplayer the next player to pass discarded cards to
     */
    public Player(int ownnumber, Player nextplayer) {
        //deleteLogFile();
        try{
            String filename = "player" + Integer.toString(ownnumber) + "_output.txt";
            writer = new FileOutputStream(filename, false);
        }
        catch (IOException e)
        {
            System.out.println("Error initilising writer");
            
        }
       
        
        
        this.ownnumber = ownnumber;
        this.nextplayer = nextplayer;
        deck = new CardGroup();
        hand = new CardGroup();
        this.gameStillInPlay = true;
        logText="";
    }

    /**
     * Constructor for Player with 1 argument, if this consturctor is called then setNextPlayer must be called before controller() or maketurn is called()
     * since it will throw a null pointer exception since nextplayer is null
     * 
     * @param ownnumber player number so they can know what cards to discard
     */
    public Player(int ownnumber) {
        //deleteLogFile();
        try{
            String filename = "player" + Integer.toString(ownnumber) + "_output.txt";
            writer = new FileOutputStream(filename, false);
        }
        catch (IOException e)
        {
            System.out.println("Error initilising writer");
            
        }
        
        deck = new CardGroup();
        hand = new CardGroup();
        this.ownnumber = ownnumber;
        this.gameStillInPlay = true;
        logText="";
    }

    /**
     * Deletes the log file for this player if it exists 
     * So that the old log data is included in the log data
     * 
     */
    public void deleteLogFile(){
        try{
            String filename = "player" + Integer.toString(ownnumber) + "_output.txt";
            File file = new File(filename);
            file.delete();
        }
        catch (Exception e)
        {
            System.out.println("Error deleting log file");
        }
    }


    /**
     * Sets the next player to pass discarded cards to
     * 
     * @param player the next player to pass discarded cards to
     */
    public void setNextPlayer(Player player) {
        this.nextplayer = player;
    }

    /**
     * Method to be called for the previous player to pass cards to current player
     * 
     * @param card the card to be passed to the current player
     */
    public void recieveCard(Card card)
    {
         
        deck.addCard(card);//make thread safe
    }

    /**
     * Makes a turn for the current player by first checking if currently winning then if deck is empty then it makes the turn 
     */    
    public void makeTurn()
    {
        logText="";
        if(isWinningHand()){
            gameStillInPlay=false;
            gameWon();
            return;
        }
        if(deck.isEmpty())
        {
            try{
                Thread.sleep(5);
            }
            catch (InterruptedException e)
            {
                System.out.println("Error sleeping thread");
            }

            return; //cannot make turn until deck is not empty

        }
        pickup();
        discard();
        
        writelog(true);
    }

    /** 
     * Controlls the player by making turns until the game is over 
    */
    public void controller()
    {
        logText+="player" + ownnumber + " initial hand: \n" + hand.toString() + "\n";
        while (gameStillInPlay){
            makeTurn();
        }
        if(winner!=ownnumber)
        {
            logText+="player "+ winner + " has informed player " + ownnumber + " that player " + winner + " has won\n";
            logText+="player" +ownnumber + " exits\n";
            logText+="player" + ownnumber + " hand: \n" + hand.toString() + "\n";
        }
        else
        {
            logText+="player " + ownnumber + " wins\n";
            logText+="player" +ownnumber + " exits\n";
            logText+="player" + ownnumber + " final hand: \n" + hand.toString() + "\n";
            
        }

        
        writelog(false);
        writeDeckOutput();
    }
    /**
     * Initialises the cards for the player
     * @param startDeck list of cards containing the cards for the deck
     * @param startHand list of cards containing the cards for the hand 
     * 
     */
    public void initialiseCards(List<Card> startDeck, List<Card> startHand)
    {
        deck.addCards(startDeck);
        hand.addCards(startHand);
    }
    /**
     * Initialises the cards for the player by adding to hand if not full and otherwise adding to deck
     * @param card card to be added
     */
    public void initialiseCard(Card card)
    {
        
        if(hand.size() < 4)
        {    hand.addCard(card);
        }
        else
        {
            deck.addCard(card);
        }
    }

    /**
     * Discards a card from the hand and passes it to the next player by finding all possible cards to discard and then randomly choosing one
     */
    private void discard()
    {
        List<Integer> discardPossibilites = new ArrayList<Integer>();
        List<Card> handClone = hand.getCards();
        for(int i=0; i<handClone.size(); i++){
            if (handClone.get(i).rank == ownnumber)continue;
            discardPossibilites.add(i);
        }
        Random rand = new Random();
        int discardPossibilitesIndex = rand.nextInt(discardPossibilites.size());

        
        int discardIndex = discardPossibilites.get(discardPossibilitesIndex);

        
        Card card = handClone.get(discardIndex);
        
        hand.removeCard(discardIndex);
        
        nextplayer.recieveCard(card);

        logText += "Player " + ownnumber + " discards a " + card.rank + " to deck " + nextplayer.ownnumber + "\n";
    }
    
    /**
     * Picks up a card from the deck and adds it to the hand
     */
    private void pickup()
    {
        //only gets called when deck not empty
        if(deck.getCard(0)==null){
            System.out.println("card at start of deck is null");
            System.out.println(deck.size());
            
            return;
        }
        Card card = deck.getCard(0);
        deck.removeCard(0);
        hand.addCard(card);
        logText += "Player " + ownnumber + " draws a " + card.rank + " from deck "+ ownnumber+"\n";
    }

    /**
     * Adds the current hand to the log string 
     */
    private void addHandToLog()
    {
        logText += "Player " + ownnumber + " current hand is " + hand.toString()+ "\n";
    }

    /**
     * Writes the log string to the log file and resets the log string
     * If it fails to write to the log file then it prints an error message to the console and it will not reset the logtext so the next time it tries to 
     * Save the log string it will also save the previous text aswell
     * 
     * @param addHandToLog if true then it will add the current hand to the log string before writing to the log file
     */
    private void writelog(Boolean addHandToLog)
    {
        if(addHandToLog)addHandToLog();
        try{

            writer.write(logText.getBytes(StandardCharsets.UTF_8));
            logText="";
        }
        catch (IOException e)
        {
            System.out.println("Error writing to log file");
        }
       
  
    }

    /**
     * Checks if the current hand is a winning hand
     * @return true if the hand is a winning hand and false otherwise
     */
    public Boolean isWinningHand()
    {
        List<Card> handClone = hand.getCards();
        int val = handClone.get(0).rank;
        if(handClone.get(1).rank == val &&  handClone.get(2).rank == val &&  handClone.get(3).rank == val) return true;
        return false;
    }

    /**
     * Sets the winner of the game and game to be over
     * @param winner player number of the winner of the game
     */
    public void SetWinner(int winner)
    {
        this.winner = winner;
        gameStillInPlay = false;
    }
    
    /**
     * Gets called when current player wins and notifies all players that the game is over
     */
    private void gameWon()
    {

        
        this.winner=ownnumber;
        System.out.println("Player " + ownnumber + " wins");
        CardGame.winner=ownnumber;
        CardGame.NotifyAllPlayers();
    }
    /**
     * Writes the deck to the output file
     */
    private void writeDeckOutput()
    {
        String filename= "deck"+ownnumber+"_output.txt";
        try{
            String text = "deck" + ownnumber + " contents: " + hand.toString();
            FileOutputStream deckwriter = new FileOutputStream(filename, false);
            deckwriter.write(text.getBytes(StandardCharsets.UTF_8));
            deckwriter.close();
        }
        catch (IOException e)
        {
            System.out.println("Error writing to log file");
        }
    }
}
