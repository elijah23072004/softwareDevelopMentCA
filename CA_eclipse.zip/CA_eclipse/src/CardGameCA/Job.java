package CardGameCA;
public class Job implements Runnable {
	private Player player;
	/**
	 * Constructor for Job 
	 * @param player player whoses controller method is called by job when executed
	 */
 	public Job (Player player) {
 		this.player = player;
 	}
	/**
	 * The run method is called when the thread is started.
	 */
 	public void run () {
 		player.controller();
 	
 		//System.out.println("Job: " + player.ownnumber + " is ending in thread : " + Thread.currentThread().getName());
   }

}
