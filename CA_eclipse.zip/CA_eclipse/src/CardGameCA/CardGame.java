package CardGameCA;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.ArrayList;
import java.util.List;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.nio.file.Files;
//import java.nio.file.Path;
import java.nio.file.Paths;
//import java.util.concurrent.Executors;
//import java.util.concurrent.ExecutorService;



public class CardGame {
    //check if log files already exist and if they do then delete them
    private static List<Player> players = new ArrayList<Player>();
    public static int winner;
    private static Scanner scan = new Scanner(System.in);

    /**
     * Reads a file and returns the text in the file as a string
     * @param path path of file to be read
     * @return text in file
     * @throws IOException if file cannot be read
     */
    private static String readFile(String path) throws IOException {
        byte[] encoded = Files.readAllBytes(Paths.get(path));
        return new String(encoded, StandardCharsets.UTF_8);
    }
    /**
     * Parses the text in the file and returns an array of cards
     * @param text text to be parsed
     * @return array of cards parsed from text
     */
    private static Card[] parseText(String text)
    {
        String[] lines = text.split("\n");
        Card[] cards = new Card[lines.length];
        for(int i=0; i<lines.length; i++)
        {
            Integer rank = Integer.parseInt(lines[i].strip());
            cards[i] = new Card(rank);
            
            
        }
        return cards;
    }
    /**
     * Checks if the deck is valid i.e number of cards is 8* number of players and all cards are positive
     * @param cards array of cards to be checked
     * @return true if the deck is valid and false otherwise
     */
    private static Boolean validDeck(Card[] cards)
    {
        if (cards == null){
            System.out.println("Please enter a valid file path");
            return false;
        } 
        if(cards.length != (8*players.size()))
        {
            System.out.println("Please enter a valid file path");
            System.out.println("No of cards is not equal to 8 times the number of players "+ "it is equal to "+ cards.length);
            System.out.println("There is "+players.size()+" players");
            return false;
        }

        for(int i=0; i<cards.length; i++)
        {
            if(cards[i].rank <0)return false;
        }
        
        return true;
    }
    /**
     * Gets the deck from the user by asking for the path of the file containing the deck and will keep asking until a path containing a valid deck is passed
     * @return array of cards in the deck
     */
    private static Card[] getDeck()
    {
        Card[] deck;
        
        do
        {
            
            deck = null;
            System.out.println("Enter the path of the file containing the deck:");
            String filename = scan.next();
            try{
                String text = readFile(filename);
                deck = parseText(text);
            }
            catch (IOException e)
            {
                System.out.println("Error reading file");
                continue;
            }
            
            
        }while (!validDeck(deck));
        return deck;
    }
    /**
     * Initialises the players by asking the user for the number of players and then initialising the players
     */
    private static void initialisePlayers()
    {
        System.out.println("Enter the number of players:");
        int numPlayers = scan.nextInt();
        scan.nextLine();
        players = new ArrayList<Player>();
        for(int i=0; i<numPlayers; i++)
        {
            players.add(new Player(i+1));
        }
        for(int i=0; i<numPlayers; i++)
        {
            players.get(i).setNextPlayer(players.get((i+1)%players.size()));
        }

    } 
    
    /**
     * Notifies all players of the winner and tells them to not make any more turns
     */
    public static void NotifyAllPlayers()
    {
        for(int i=0; i<players.size(); i++)
        {
            if((i+1)==winner)continue;
            players.get(i).SetWinner(winner);
        }
    }
    /**
     * Checks if any player has a winning hand and if they do then sets the winner and notifies all players used for checking if a player has a winning hand before game starts
     * @return
     */
    public static boolean checkForWinningHand()
    {
        for(int i=0; i<players.size(); i++)
        {
            if(players.get(i).isWinningHand())
            {
                winner = i;
                NotifyAllPlayers();
                return true;
            }
        }
        return false;
    }
    /**
     * Main method of the game which initialises the players and the deck and then starts the game
     * @param args
     */
    public static void main(String[] args)
    {
        initialisePlayers();
        Card[] deck = getDeck();
        scan.close();
        for(int i=0; i<deck.length; i++)
        {
            players.get(i%players.size()).initialiseCard(deck[i]);
        }
        //check if any player has a winning hand 
        if(checkForWinningHand())return;
        //if not then start the game
;
        startPlayConcurrent();
        
    }
    /**
     * Starts the game by starting the threads for each player
     */
    private static void startPlayConcurrent()
    {
        
        ExecutorService pool = Executors.newFixedThreadPool(players.size());
 		for (int i = 0; i < players.size(); i++) {
 		    
 			pool.execute(new Job(players.get(i)));
 		}
        pool.shutdown();
    }


}
